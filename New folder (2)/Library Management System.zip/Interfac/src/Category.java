
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;
public class Category extends javax.swing.JFrame {

   Connection con=null;
   PreparedStatement pst=null;
  ResultSet rs;
   
    public Category() {
        initComponents();
      showTableData();
    }
    
     
    
      @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtcategory = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtcate = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        txtstat = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        txtcategory.setBackground(new java.awt.Color(0, 0, 0));
        txtcategory.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Category", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Times New Roman", 2, 24), new java.awt.Color(255, 255, 51))); // NOI18N
        txtcategory.setForeground(new java.awt.Color(255, 255, 102));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 102));
        jLabel1.setText("Category Name");

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 102));
        jLabel2.setText("Status");

        txtcate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtcateActionPerformed(evt);
            }
        });

        jButton1.setBackground(new java.awt.Color(51, 255, 51));
        jButton1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 51, 51));
        jButton1.setText("Add");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(51, 255, 51));
        jButton2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 51, 51));
        jButton2.setText("Update");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(51, 255, 51));
        jButton3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 51, 51));
        jButton3.setText("Delete");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setBackground(new java.awt.Color(51, 255, 51));
        jButton4.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 51, 51));
        jButton4.setText("Cancel");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Category  Name", "Status"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Object.class, java.lang.Object.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        txtstat.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Active", "Deactive" }));
        txtstat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtstatActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout txtcategoryLayout = new javax.swing.GroupLayout(txtcategory);
        txtcategory.setLayout(txtcategoryLayout);
        txtcategoryLayout.setHorizontalGroup(
            txtcategoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(txtcategoryLayout.createSequentialGroup()
                .addGap(64, 64, 64)
                .addGroup(txtcategoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(txtcategoryLayout.createSequentialGroup()
                        .addGroup(txtcategoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(45, 45, 45)
                        .addGroup(txtcategoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtcate)
                            .addComponent(txtstat, 0, 186, Short.MAX_VALUE))
                        .addGap(24, 24, 24))
                    .addGroup(txtcategoryLayout.createSequentialGroup()
                        .addGroup(txtcategoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, 76, Short.MAX_VALUE))
                        .addGap(90, 90, 90)
                        .addGroup(txtcategoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton4, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(58, 58, 58)))
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 287, Short.MAX_VALUE)
                .addGap(15, 15, 15))
        );
        txtcategoryLayout.setVerticalGroup(
            txtcategoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(txtcategoryLayout.createSequentialGroup()
                .addGap(74, 74, 74)
                .addGroup(txtcategoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(txtcategoryLayout.createSequentialGroup()
                        .addGroup(txtcategoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(txtcate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(36, 36, 36)
                        .addGroup(txtcategoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtstat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(33, 33, 33)
                        .addGroup(txtcategoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton2)
                            .addComponent(jButton1))
                        .addGap(44, 44, 44)
                        .addGroup(txtcategoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton3)
                            .addComponent(jButton4))))
                .addContainerGap(135, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(txtcategory, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(txtcategory, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtcateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcateActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtcateActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
       try{
     DefaultTableModel d1=(DefaultTableModel)jTable1.getModel();
     int selectIndex=jTable1.getSelectedRow();
     int ID=Integer.parseInt(d1.getValueAt(selectIndex, 0).toString());
     
           String query="DELETE FROM category WHERE ID=?";
       con= DriverManager.getConnection("jdbc:mysql://localhost/library","root","");
         pst=con.prepareStatement(query);
              pst.setInt(1,ID);

       pst.executeUpdate();
       JOptionPane.showMessageDialog(null,"Deleted successfully");
       }
     
       catch(HeadlessException | SQLException ex){
           JOptionPane.showMessageDialog(null,ex);
 
       }  
       showTableData();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void txtstatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtstatActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtstatActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
     
        try{
           String query="INSERT INTO `category`( `CategoryName`, `Status`) VALUES (?, ?)";
       con= DriverManager.getConnection("jdbc:mysql://localhost/library","root","");
         pst=con.prepareStatement(query);
       pst.setString(1, txtcate.getText());
        pst.setString(2, txtstat.getSelectedItem().toString());
       pst.executeUpdate();
       JOptionPane.showMessageDialog(null,"Added successfully");
       }
     
       catch(HeadlessException | SQLException ex){
           JOptionPane.showMessageDialog(null,ex);
 
       }
showTableData();
          
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
 try{
     DefaultTableModel d1=(DefaultTableModel)jTable1.getModel();
     int selectIndex=jTable1.getSelectedRow();
     int ID=Integer.parseInt(d1.getValueAt(selectIndex, 0).toString());
     
           String query="UPDATE category SET CategoryName=?,Status=? WHERE ID=?";
       con= DriverManager.getConnection("jdbc:mysql://localhost/library","root","");
         pst=con.prepareStatement(query);
      
       pst.setString(1, txtcate.getText());
        pst.setString(2, txtstat.getSelectedItem().toString());
              pst.setInt(3, ID);

       pst.executeUpdate();
       JOptionPane.showMessageDialog(null,"Updated successfully");
       }
     
       catch(HeadlessException | SQLException ex){
           JOptionPane.showMessageDialog(null,ex);
 
       }  
       showTableData();
            jButton1.setEnabled(true);


    }//GEN-LAST:event_jButton2ActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
     DefaultTableModel d1=(DefaultTableModel)jTable1.getModel();
     int selectIndex=jTable1.getSelectedRow();
     int ID=Integer.parseInt(d1.getValueAt(selectIndex, 0).toString());
      txtcate.setText(d1.getValueAt(selectIndex, 1).toString());
     txtstat.setSelectedItem(d1.getValueAt(selectIndex, 2).toString());
     
     jButton1.setEnabled(false);
    }//GEN-LAST:event_jTable1MouseClicked

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
       this.setVisible(false);
    }//GEN-LAST:event_jButton4ActionPerformed
public  void showTableData()
{
    try {
      con=DriverManager.getConnection("jdbc:mysql://localhost/library","root","");
      String sql="SELECT * FROM category";
      pst=con.prepareStatement(sql);
      rs=pst.executeQuery();
      jTable1.setModel(DbUtils.resultSetToTableModel(rs));
    }
    catch (Exception ex)
    {
       JOptionPane.showMessageDialog(null, ex);
    }
}
   
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
      
        //</editor-fold>
FrontPage obj=new FrontPage();
        obj.fornt();
        /* Create and display the form */
        /*java.awt.EventQueue.invokeLater(() -> {
            new Category().setVisible(true);
        });
        */
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField txtcate;
    private javax.swing.JPanel txtcategory;
    private javax.swing.JComboBox<String> txtstat;
    // End of variables declaration//GEN-END:variables


}
