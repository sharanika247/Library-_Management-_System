-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 10, 2021 at 07:40 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library`
--

-- --------------------------------------------------------

--
-- Table structure for table `author`
--

CREATE TABLE `author` (
  `ID` int(50) NOT NULL,
  `Name` varchar(150) NOT NULL,
  `Address` varchar(200) NOT NULL,
  `Phone` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `author`
--

INSERT INTO `author` (`ID`, `Name`, `Address`, `Phone`) VALUES
(3, 'Abir', 'uttara', '0173938494'),
(4, 'Nayem', 'Uttara', '01643289765'),
(5, 'Sharanika Das', 'Azim pur', '01853039335');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `ID` int(50) NOT NULL,
  `bname` varchar(50) NOT NULL,
  `Category` varchar(200) NOT NULL,
  `Author` varchar(110) NOT NULL,
  `Publisher` varchar(100) NOT NULL,
  `Contents` varchar(200) NOT NULL,
  `Pages` varchar(255) NOT NULL,
  `Edition` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`ID`, `bname`, `Category`, `Author`, `Publisher`, `Contents`, `Pages`, `Edition`) VALUES
(1, 'Java', 'IEE', 'Nayem', 'Balagurusamy', 'Interface', '1230', 'second'),
(2, 'Business', 'RTR', 'Abir', 'Book House', 'Introduction', '320', '5th'),
(3, 'Distionary', 'Business', 'Prona Roy', 'Book House', 'Advanced', '456', '4th'),
(5, 'C#', 'BCE', 'Abir', 'Balagurusamy', 'Interface', '1234', '3rd');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `ID` int(50) NOT NULL,
  `CategoryName` varchar(200) NOT NULL,
  `Status` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`ID`, `CategoryName`, `Status`) VALUES
(1, '', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `lendbook`
--

CREATE TABLE `lendbook` (
  `ID` int(50) NOT NULL,
  `memberid` varchar(11) NOT NULL,
  `bname` varchar(50) NOT NULL,
  `issuedate` date NOT NULL,
  `returndate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lendbook`
--

INSERT INTO `lendbook` (`ID`, `memberid`, `bname`, `issuedate`, `returndate`) VALUES
(3, '3', 'Distionary', '2021-03-19', '2021-03-27'),
(6, '1', 'Distionary', '2021-03-26', '2021-03-31'),
(7, '2', 'Business', '2021-03-04', '2021-03-30'),
(8, '2', 'Business', '2021-03-11', '2021-03-30'),
(9, '1', 'Java', '2021-03-04', '2021-03-28'),
(12, '3', 'Business', '2021-03-26', '2021-03-27'),
(13, '3', 'C#', '2021-04-05', '2021-04-12'),
(14, '3', 'Distionary', '2021-04-09', '2021-04-16');

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `ID` int(50) NOT NULL,
  `Name` varchar(200) NOT NULL,
  `Address` varchar(200) NOT NULL,
  `Phone` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`ID`, `Name`, `Address`, `Phone`) VALUES
(1, 'SK Nayem', 'Uttara', '01833451234'),
(3, 'Tanvir', 'Dhaka', '01356321456'),
(4, 'Naughty Gazi', 'Dhanmondi', '01523456789'),
(5, 'Mr. ABC', 'tyu', '897654567');

-- --------------------------------------------------------

--
-- Table structure for table `publisher`
--

CREATE TABLE `publisher` (
  `ID` int(20) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Address` varchar(200) NOT NULL,
  `Phone` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `publisher`
--

INSERT INTO `publisher` (`ID`, `Name`, `Address`, `Phone`) VALUES
(1, 'Book House', 'Dhaka', '01643678567'),
(2, 'Balagurusamy', 'India', '7875556');

-- --------------------------------------------------------

--
-- Table structure for table `returnbook`
--

CREATE TABLE `returnbook` (
  `Member_ID` int(100) NOT NULL,
  `Book_Name` varchar(200) NOT NULL,
  `Elapsed_Days` int(50) NOT NULL,
  `Fine` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `returnbook`
--

INSERT INTO `returnbook` (`Member_ID`, `Book_Name`, `Elapsed_Days`, `Fine`) VALUES
(1, 'Distionary', 2, 200),
(3, 'Distionary', 3, 300);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `author`
--
ALTER TABLE `author`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `lendbook`
--
ALTER TABLE `lendbook`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `publisher`
--
ALTER TABLE `publisher`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `author`
--
ALTER TABLE `author`
  MODIFY `ID` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `ID` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `ID` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `lendbook`
--
ALTER TABLE `lendbook`
  MODIFY `ID` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `member`
--
ALTER TABLE `member`
  MODIFY `ID` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `publisher`
--
ALTER TABLE `publisher`
  MODIFY `ID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
